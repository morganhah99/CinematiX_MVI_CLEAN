package com.kryptopass.common.state

// NOTE: represent single-shot (one-off) events (emit using channel flows)
interface UiSingleEvent