package com.kryptopass.common.nav

data class MovieInput(val movieId: Int?)