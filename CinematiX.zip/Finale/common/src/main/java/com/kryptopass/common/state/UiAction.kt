package com.kryptopass.common.state

// NOTE: represent shared flow of app (good for actions as we do not want last action emitted twice)
interface UiAction